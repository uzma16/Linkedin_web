# Dev Tracker

Dev Tracker is a tool that monitors file activities in a directory and tracks time spent on various development tasks.

## Installation

```bash
pip install dev_tracker
